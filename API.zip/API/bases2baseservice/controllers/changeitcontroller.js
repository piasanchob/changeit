"use strict";
exports.__esModule = true;
exports.changeitController = void 0;
var changeit_data_1 = require("../repositories/changeit_data");
var common_1 = require("../common");
var changeitController = /** @class */ (function () {
    function changeitController() {
        this.log = new common_1.Logger();
        try {
        }
        catch (e) {
            this.log.error(e);
        }
    }
    changeitController.getInstance = function () {
        if (!this.instance) {
            this.instance = new changeitController();
        }
        return this.instance;
    };
    changeitController.prototype.listchangeit = function () {
        var changeitdb = new changeit_data_1.changeit_data();
        return changeitdb.getsomequeries();
    };
    changeitController.prototype.listchangeitPool = function () {
        var changeitdb = new changeit_data_1.changeit_data();
        return changeitdb.getsomequeriespool();
    };
    changeitController.prototype.listchangeitGlobalPool = function () {
        var changeitdb = new changeit_data_1.changeit_data();
        return changeitdb.getqueriesglobalpool();
    };
    changeitController.prototype.listAplicarHabito = function () {
        var changeitdb = new changeit_data_1.changeit_data();
        return changeitdb.AplicarHabito();
    };
    changeitController.prototype.listHacerPosteo = function () {
        var changeitdb = new changeit_data_1.changeit_data();
        return changeitdb.HacerPosteo();
    };
    return changeitController;
}());
exports.changeitController = changeitController;
