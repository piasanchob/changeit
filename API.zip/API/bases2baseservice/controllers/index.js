"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
exports.__esModule = true;
exports.changeitController = exports.ArticleController = exports.HateController = void 0;
var hatecontroller_1 = require("./hatecontroller");
__createBinding(exports, hatecontroller_1, "HateController");
var articlescontroller_1 = require("./articlescontroller");
__createBinding(exports, articlescontroller_1, "ArticleController");
var changeitcontroller_1 = require("./changeitcontroller");
__createBinding(exports, changeitcontroller_1, "changeitController");
