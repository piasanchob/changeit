import { changeit_data } from '../repositories/changeit_data'
import { Logger } from '../common'

export class changeitController {

    private static instance: changeitController;
    private log: Logger;
    private db : any;

    private constructor()
    {
        this.log = new Logger();
        try
        {
        } catch (e)
        {
            this.log.error(e);
        }
    }

    public static getInstance() : changeitController
    {
        if (!this.instance)
        {
            this.instance = new changeitController();
        }
        return this.instance;
    }



    public listchangeit() : Promise<any>
    {
        const changeitdb = new changeit_data();
        return changeitdb.getsomequeries();

    }

    public listchangeitPool() : Promise<any>
    {
        const changeitdb = new changeit_data();
        return changeitdb.getsomequeriespool();

    }

    public listchangeitGlobalPool() : Promise<any>
    {
        const changeitdb = new changeit_data();
        return changeitdb.getqueriesglobalpool();

    }

    public listAplicarHabito() : Promise<any>
    {
        const changeitdb = new changeit_data();
        return changeitdb.AplicarHabito();

    }

    public listHacerPosteo() : Promise<any>
    {
        const changeitdb = new changeit_data();
        return changeitdb.HacerPosteo();

    }

}