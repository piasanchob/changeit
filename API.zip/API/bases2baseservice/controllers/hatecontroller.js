"use strict";
exports.__esModule = true;
exports.HateController = void 0;
var common_1 = require("../common");
var mongoose = require("mongoose");
var objectostohate = ["los gatos", "las bicis", "la basura", "madrugar", "ver tele", "los cuervos", "el aguacate", "tv azteca"];
var allhashtags = ["#malavibra", "#nohate", "#everyday", "#oneday", "#popular", "#otrohashtag", "#region", "#mapa", "#rojo", "#blackhole"];
var HateController = /** @class */ (function () {
    function HateController() {
        var _this = this;
        this.log = new common_1.Logger();
        try {
            mongoose.connect('mongodb://10.0.0.6:27017/socialhate', {
                useNewUrlParser: true,
                useUnifiedTopology: true,
                socketTimeoutMS: 2000
            });
            this.db = mongoose.connection;
            this.db.on('error', function () {
                _this.log.error("No puedo conectar a mongo");
            });
            this.db.once('open', function () {
                _this.log.info("Conectado a mongo");
            });
        }
        catch (e) {
            this.log.error(e);
        }
    }
    HateController.prototype.fillHatePosts = function () {
        var _this = this;
        try {
            var quantity = 100;
            var _loop_1 = function () {
                var willpaid = Math.random() <= 0.5 ? true : false;
                var amount = willpaid ? (Math.random() * 300000.00) + 2000.0 : 0.0;
                var aproxHashtags = Math.trunc(Math.random() * 4 + 1) / allhashtags.length;
                var postDate = new Date();
                postDate.setDate(postDate.getDate() - Math.trunc(Math.random() * 700));
                var newPost = new common_1.HatePost({
                    description: 'Odio ' + objectostohate[Math.trunc(Math.random() * objectostohate.length)],
                    paid: willpaid,
                    amountPaid: amount,
                    likes: Math.trunc((Math.random() * 30000) + 2000),
                    hashtags: allhashtags.filter(function (element, index, array) {
                        if (Math.random() <= aproxHashtags) {
                            return true;
                        }
                    }),
                    date: postDate
                });
                newPost.save(function (err, post) {
                    if (err) {
                        _this.log.error(err);
                    }
                });
                quantity--;
            };
            while (quantity > 0) {
                _loop_1();
            }
        }
        catch (e) {
            this.log.error(e);
        }
    };
    HateController.getInstance = function () {
        if (!this.instance) {
            this.instance = new HateController();
        }
        return this.instance;
    };
    return HateController;
}());
exports.HateController = HateController;
