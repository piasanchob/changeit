"use strict";
exports.__esModule = true;
var express = require("express");
var bodyParser = require("body-parser");
var common_1 = require("../common");
var kindness_1 = require("./kindness");
var hatesocialrouter_1 = require("./hatesocialrouter");
var articlesrouter_1 = require("./articlesrouter");
var changeitrouter_1 = require("./changeitrouter");
var Routes = /** @class */ (function () {
    function Routes() {
        this.express = express();
        this.logger = new common_1.Logger();
        this.middleware();
        this.routes();
    }
    // Configure Express middleware.
    Routes.prototype.middleware = function () {
        this.express.use(bodyParser.json());
        this.express.use(bodyParser.urlencoded({ extended: false }));
    };
    Routes.prototype.routes = function () {
        this.express.use('/kind', kindness_1.kindnessrouter);
        this.express.use('/hate', hatesocialrouter_1.hatesocialrouter);
        this.express.use('/articles', articlesrouter_1.articlesrouter);
        this.express.use('/changeit', changeitrouter_1.changeitrouter);
        this.logger.info("Funciona API");
    };
    return Routes;
}());
exports["default"] = new Routes().express;
