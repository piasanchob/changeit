import * as express from 'express';
import { Logger } from '../common'
import { changeitController } from '../controllers'

const app = express();
const log = new Logger();

app.get("/listchangeit", (req, res, next) => {

    changeitController.getInstance().listchangeit()
    .then((data)=>{
        res.json(data);
    })
    .catch((err)=>{
        log.error(err);
        return "";
    })

});

app.get("/listchangeitpool", (req, res, next) => {

    changeitController.getInstance().listchangeitPool()
    .then((data)=>{
        res.json(data);
    })
    .catch((err)=>{
        log.error(err);
        return "";
    })

});

app.get("/listchangeitglobalpool", (req, res, next) => {

    changeitController.getInstance().listchangeitGlobalPool()
    .then((data)=>{
        res.json(data);
    })
    .catch((err)=>{
        log.error(err);
        return "";
    })

});

app.get("/aplicarhabito", (req, res, next) => {

    changeitController.getInstance().listAplicarHabito()
    .then((data)=>{
        res.json(data);
    })
    .catch((err)=>{
        log.error(err);
        return "";
    })

});

app.get("/hacerposteo", (req, res, next) => {

    changeitController.getInstance().listHacerPosteo()
    .then((data)=>{
        res.json(data);
    })
    .catch((err)=>{
        log.error(err);
        return "";
    })

});

export { app as changeitrouter };