"use strict";
exports.__esModule = true;
exports.changeitrouter = void 0;
var express = require("express");
var common_1 = require("../common");
var controllers_1 = require("../controllers");
var app = express();
exports.changeitrouter = app;
var log = new common_1.Logger();
app.get("/listchangeit", function (req, res, next) {
    controllers_1.changeitController.getInstance().listchangeit()
        .then(function (data) {
        res.json(data);
    })["catch"](function (err) {
        log.error(err);
        return "";
    });
});
app.get("/listchangeitpool", function (req, res, next) {
    controllers_1.changeitController.getInstance().listchangeitPool()
        .then(function (data) {
        res.json(data);
    })["catch"](function (err) {
        log.error(err);
        return "";
    });
});
app.get("/listchangeitglobalpool", function (req, res, next) {
    controllers_1.changeitController.getInstance().listchangeitGlobalPool()
        .then(function (data) {
        res.json(data);
    })["catch"](function (err) {
        log.error(err);
        return "";
    });
});
app.get("/aplicarhabito", function (req, res, next) {
    controllers_1.changeitController.getInstance().listAplicarHabito()
        .then(function (data) {
        res.json(data);
    })["catch"](function (err) {
        log.error(err);
        return "";
    });
});
app.get("/hacerposteo", function (req, res, next) {
    controllers_1.changeitController.getInstance().listHacerPosteo()
        .then(function (data) {
        res.json(data);
    })["catch"](function (err) {
        log.error(err);
        return "";
    });
});
