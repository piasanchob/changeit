"use strict";
exports.__esModule = true;
exports.hatesocialrouter = void 0;
var express = require("express");
var controllers_1 = require("../controllers");
var app = express();
exports.hatesocialrouter = app;
app.put("/rellenar", function (req, res, next) {
    controllers_1.HateController.getInstance().fillHatePosts();
    res.json({ message: "Ok" });
});
