
export class Article
{
    public author : string;
    public title: string;
    public otro: string;
}