"use strict";
exports.__esModule = true;
exports.HatePost = void 0;
var mongoose = require("mongoose");
var Schema = mongoose.Schema;
exports.HatePost = mongoose.model('HatePost', new Schema({
    description: String,
    date: { type: Date, "default": Date.now },
    paid: Boolean,
    amountPaid: { type: Number, "default": 0.0 },
    likes: Number,
    hashtags: [String]
}));
