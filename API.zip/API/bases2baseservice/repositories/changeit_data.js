"use strict";
exports.__esModule = true;
exports.changeit_data = void 0;
var sql = require('mssql');
var basicconfig = {
    user: 'sa',
    password: '123456',
    database: 'changeit',
    server: 'localhost',
    port: 1433,
    "dialectOptions": {
        "instanceName": "DESKTOP-M6KOQA4"
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};
var poolconfig = {
    user: 'sa',
    password: '123456',
    database: 'changeit',
    server: 'localhost',
    port: 1433,
    "dialectOptions": {
        "instanceName": "DESKTOP-M6KOQA4"
    },
    pool: {
        max: 3,
        min: 1,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};
var poolglobalconfig = {
    user: 'sa',
    password: '123456',
    database: 'changeit',
    server: 'localhost',
    port: 1433,
    "dialectOptions": {
        "instanceName": "DESKTOP-M6KOQA4"
    },
    pool: {
        max: 6,
        min: 2,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
};
var querygetonequery = 'Select * from RedesSociales';
var HacerPosteo = 'EXEC HacerPosteo';
var AplicarHabito = 'EXEC AplicarHabito';
sql.on('error', function (err) {
    console.log(err);
});
var changeit_data = /** @class */ (function () {
    function changeit_data() {
        if (changeit_data.poolconnector == null) {
            changeit_data.poolconnector = new sql.ConnectionPool(poolglobalconfig);
            changeit_data.globalpool = changeit_data.poolconnector.connect();
            console.log("global pool inicializado");
        }
    }
    changeit_data.prototype.getsomequeries = function () {
        return new Promise(function (resolve, reject) {
            sql.connect(basicconfig).then(function () {
                sql.query(querygetonequery)
                    .then(function (data) {
                    resolve(data.recordset[0]);
                })["catch"](function (err) {
                    reject(err);
                });
            })["catch"](function (err) {
                console.log(err);
            });
        });
    };
    changeit_data.prototype.getsomequeriespool = function () {
        return new Promise(function (resolve, reject) {
            sql.connect(poolconfig).then(function () {
                sql.query(querygetonequery)
                    .then(function (data) {
                    /*resolve(data.recordset[0])*/
                })["catch"](function (err) {
                    reject(err);
                });
            })["catch"](function (err) {
                console.log(err);
            });
        });
    };
    changeit_data.prototype.getqueriesglobalpool = function () {
        return new Promise(function (resolve, reject) {
            changeit_data.globalpool.then(function (pool) {
                pool.request().query(querygetonequery)
                    .then(function (data) {
                    /*resolve(data.recordset[0])*/
                })["catch"](function (err) {
                    reject(err);
                });
            })["catch"](function (err) {
                console.log(err);
            });
        });
    };
    changeit_data.prototype.AplicarHabito = function () {
        return new Promise(function (resolve, reject) {
            sql.connect(poolconfig).then(function () {
                sql.query(AplicarHabito)
                    .then(function (data) {
                    /*resolve(data.recordset[0])*/
                })["catch"](function (err) {
                    reject(err);
                });
            })["catch"](function (err) {
                console.log(err);
            });
        });
    };
    changeit_data.prototype.HacerPosteo = function () {
        return new Promise(function (resolve, reject) {
            sql.connect(poolconfig).then(function () {
                sql.query(HacerPosteo)
                    .then(function (data) {
                    /*resolve(data.recordset[0])*/
                })["catch"](function (err) {
                    reject(err);
                });
            })["catch"](function (err) {
                console.log(err);
            });
        });
    };
    return changeit_data;
}());
exports.changeit_data = changeit_data;
