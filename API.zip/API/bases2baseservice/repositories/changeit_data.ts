import { start } from 'repl'
import { Logger } from '../common'


const sql = require('mssql')

const basicconfig = {
    user: 'sa',
    password: '123456',
    database: 'changeit',
    server: 'localhost',
    port: 1433,
    "dialectOptions": {
        "instanceName": "DESKTOP-M6KOQA4"
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
}

const poolconfig = {
    user: 'sa',
    password: '123456',
    database: 'changeit',
    server: 'localhost',
    port: 1433,
    "dialectOptions": {
        "instanceName": "DESKTOP-M6KOQA4"
    },
    pool: {
        max: 3,
        min: 1,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
}

const poolglobalconfig = {
    user: 'sa',
    password: '123456',
    database: 'changeit',
    server: 'localhost',
    port: 1433,
    "dialectOptions": {
        "instanceName": "DESKTOP-M6KOQA4"
    },
    pool: {
        max: 6,
        min: 2,
        idleTimeoutMillis: 30000
    },
    options: {
        encrypt: true,
        trustServerCertificate: true
    }
}

const querygetonequery = 'Select * from RedesSociales';

const HacerPosteo = 'EXEC HacerPosteo';
const AplicarHabito = 'EXEC AplicarHabito';


sql.on('error', (err : any) =>{
    console.log(err)
})

export class changeit_data {
    private log: Logger;
    private static poolconnector: any;
    private static globalpool: any;

    public constructor()
    {
        if (changeit_data.poolconnector==null)
        {
            changeit_data.poolconnector = new sql.ConnectionPool(poolglobalconfig);
            changeit_data.globalpool = changeit_data.poolconnector.connect();
            console.log("global pool inicializado")
        }
    }

    public getsomequeries() : Promise<any>
    {
        return new Promise<any>((resolve, reject)=> {
            sql.connect(basicconfig).then(() => {
                sql.query(querygetonequery)
                .then((data : any) => {
                    resolve(data.recordset[0])
                })
                .catch((err: any) =>{
                    reject(err)
                })
            })
            .catch((err : any) => {
                console.log(err)
            })
        });
    }

    public getsomequeriespool() : Promise<any>
    {
        return new Promise<any>((resolve, reject)=> {
            sql.connect(poolconfig).then(() => {
                sql.query(querygetonequery)
                .then((data : any) => {
                    /*resolve(data.recordset[0])*/
                })
                .catch((err: any) =>{
                    reject(err)
                })
            })
            .catch((err : any) => {
                console.log(err)
            })
        });
    }

    public getqueriesglobalpool() : Promise<any>
    {
        return new Promise<any>((resolve, reject)=> {
            changeit_data.globalpool.then((pool:any) => {
                pool.request().query(querygetonequery)
                .then((data : any) => {
                    /*resolve(data.recordset[0])*/
                })
                .catch((err: any) =>{
                    reject(err)
                })
            })
            .catch((err : any) => {
                console.log(err)
            })
        });
    }

    public AplicarHabito() : Promise<any>
    {
        return new Promise<any>((resolve, reject)=> {
            sql.connect(poolconfig).then(() => {
                sql.query(AplicarHabito)
                .then((data : any) => {
                    /*resolve(data.recordset[0])*/
                })
                .catch((err: any) =>{
                    reject(err)
                })
            })
            .catch((err : any) => {
                console.log(err)
            })
        });
    }

    public HacerPosteo() : Promise<any>
    {
        return new Promise<any>((resolve, reject)=> {
            sql.connect(poolconfig).then(() => {
                sql.query(HacerPosteo)
                .then((data : any) => {
                    /*resolve(data.recordset[0])*/
                })
                .catch((err: any) =>{
                    reject(err)
                })
            })
            .catch((err : any) => {
                console.log(err)
            })
        });
    }

}