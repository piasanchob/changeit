"use strict";
exports.__esModule = true;
exports.articles_data = void 0;
var AWS = require("aws-sdk");
var articles_data = /** @class */ (function () {
    function articles_data() {
        this.dyClient = new AWS.DynamoDB.DocumentClient({ "region": "us-east-1" });
    }
    articles_data.prototype.getAllArticles = function () {
        var params = {
            TableName: 'articles',
            KeyConditionExpression: 'author = :elautor',
            ExpressionAttributeValues: {
                ':elautor': 'rodrigo valdes'
            }
        };
        return this.dyClient.query(params).promise();
    };
    return articles_data;
}());
exports.articles_data = articles_data;
